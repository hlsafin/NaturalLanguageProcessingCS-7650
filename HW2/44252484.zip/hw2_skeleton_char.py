import math, random
from collections import Counter

################################################################################
# Part 0: Utility Functions
################################################################################

def start_pad(n):
    ''' Returns a padding string of length n to append to the front of text
        as a pre-processing step to building n-grams '''
    return '~' * n

def ngrams(n, text):

    ''' Returns the ngrams of the text as tuples where the first element is
        the length-n context and the second is the character '''

    text2=start_pad(n)+text
    #print(text)
    char_list=[text2[x:x+n] for x in range(len(text2)-n)]
    #
    # for x in range(n):
    #     char_list.append('stop')
    #print(char_list)
    list=[]
    for x,y in zip(char_list,text):
        list.append((x,y))

    #print(list)



    # for x in range( len(text)):
    #     list.append(char_list.pop(),list.)
    #
    # new_list=Counter(char_list)
    # # for x in char_list:
    # #     count=x.count(x)
    # #     new_list.append([x,count])
    # print(new_list)
    # list = [(k, v) for k, v in new_list.items()]
    # print(list)
    #res=Counter(char_list.values())
    #red
    return list
    #return text
    #return [text[i:i + n] for i in range(0, len(text), n)]
#ngrams(3, 'abcdefghi')

def create_ngram_model(model_class, path, n=2, k=0):
    ''' Creates and returns a new n-gram model trained on the path file '''
    model = model_class(n, k)
    with open(path, encoding='utf-8', errors='ignore') as f:
        model.update(f.read())
    return model


################################################################################
# Part 1: Basic N-Gram Model
################################################################################

class NgramModel(object):
    ''' A basic n-gram model using add-k smoothing '''

    def __init__(self, n, k):
        self.n = n
        self.k = k
        self.text={}
        self.text_info=[]
        self.vocab=set()
        self.occurances=Counter()
        self.contextoccurance=Counter()
        #pass
        #self.count = collections.defaultdict(int)
        #self.ngram = collections.defaultdict(int)

    def get_vocab(self):
        ''' Returns the set of characters in the vocab '''
        #print(set(self.text))
        return self.vocab
        #return set(self.text) -{'~'}
        #pass

    def update(self, text):
        ''' Updates the model n-grams based on text '''


        self.text=Counter('~'+text)

        self.vocab=set(self.text)-{'~'}


        #self.text_info.append(ngrams(self.n,text))
        new_set_words=ngrams(self.n, text)
        new_word_list = []
        new_cont_list=[]
        for x in new_set_words:
            new_cont_list.append(x)
            new_word_list.append(x[0])
        #
        #
        # self.occurances =Counter(self.text_info)
        # self.contextoccurance = Counter(new_word_list)

        self.occurances.update(new_cont_list)
        self.contextoccurance.update(new_word_list)

        # self.occurances = Counter(self.text_info)
        # self.contextoccurance = Counter(new_word_list)



        #print(self.text)


        #self.text.append(text)
        #pass

    def prob(self, context, char):
        sumofconetext=0
        sumofchar=0

        if context not in self.contextoccurance:
            return 1/len(self.get_vocab())

            print('error')

        # for x in self.text_info:
        #     if x[0]==context:
        #         sumofconetext=sumofconetext+1
        #         if x[1]==char:
        #             sumofchar=sumofchar+1
        if self.occurances.get((context,char))==None:
            value=0
        else:
            value=self.occurances.get((context,char))
        ''' Returns the probability of char appearing after context '''
        #return sumofchar/sumofconetext
        return (value+self.k)/(self.contextoccurance.get(context)+self.k*len(self.vocab))
        #return self.text.get(char)self.occurances.get((context,char))
        #pass


    def random_char(self, context):
        ''' Returns a random character based on the given context and the
            n-grams learned by this model '''
        #random.seed(15)
        order_vocab = sorted(list(self.get_vocab()))
        r = random.random()
        accu_prob = 0
        idx = 0

        while idx < len(self.get_vocab()) and accu_prob < r:
            accu_prob += self.prob(context, order_vocab[idx])
            idx += 1
        if accu_prob < r:
            print("Error")

        return order_vocab[idx - 1]



    def random_text(self, length):
        ''' Returns text of the specified character length based on the
            n-grams learned by this model '''

        starting_context = '~' * self.n
        generated_text = ""
        current_context = starting_context
        for i in range(1,length):
            random_char = self.random_char(starting_context)
            current_context += random_char
            generated_text += random_char
            starting_context = current_context[i + 1:i + 1 + self.n]

        return generated_text




    def perplexity(self, text):
        ''' Returns the perplexity of text based on the n-grams learned by
            this model '''
        result = 0
        res = ngrams(self.n,text)
        for context,t in res:
            #print(context,t)
            c_prob = self.prob(context,t)
            if c_prob == 0:
                result = float('inf')
                return result
            val=self.prob(context,t)
            result = result+  math.log(val)
        #print(result,math.exp(result))
        res=(-1/len(text))*result
        #result  = math.exp(res)
        #result  = 1.0/math.pow(2,result)
        return math.exp(res)
        # return 'hey'

        #pass

import collections


# m = NgramModel(1, 0)
# m.update('abab')
# m.get_vocab()
# m.update('abcd')
# m.get_vocab()
# print(m.prob('a', 'b'))
# print(m.prob('~', 'c'))
# print(m.prob('b', 'c'))
# m.update('abab')
# m.update('abcd')
# random.seed(123)
# print([m.random_char('') for i in range(25)])
# random.seed(1)
# m = NgramModel(1, 0)
# m.update('abc')
# m.update('cde')
# random.seed(1)
# m = NgramModel(1, 0)
# m.update('abab')
# m.update('abcd')
# random.seed(1)
#print(m.random_text(25))
# random.seed(1)
# m = create_ngram_model(NgramModel, 'shakespeare_input.txt', 5)
# print(m.random_text(55))
#
# m = NgramModel(1, 0)
# m.update('abab')
# m.update('abcd')
# print(m.perplexity('abcd'))

# m = NgramModel(1, 1)
# m.update('abab')
# m.update('abcd')
# print(m.prob('a', 'a'))
# print(m.perplexity('abca'))
#
# m = create_ngram_model(NgramModel, 'shakespeare_input.txt', 2, k=0.1)
# print(len(m.get_vocab()))
# with open('shakespeare_sonnets.txt', encoding='utf-8', errors='ignore') as f:
#     print(m.perplexity(f.read()))
################################################################################
# Part 2: N-Gram Model with Interpolation
################################################################################

class NgramModelWithInterpolation(NgramModel):
    ''' An n-gram model with interpolation '''

    def __init__(self, n, k):
        pass

    def get_vocab(self):
        pass

    def update(self, text):
        pass

    def prob(self, context, char):
        pass

################################################################################
# Part 3: Your N-Gram Model Experimentation
################################################################################

if __name__ == '__main__':
    pass