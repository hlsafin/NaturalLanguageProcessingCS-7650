import math, random
from typing import List, Tuple

################################################################################
# Part 0: Utility Functions
################################################################################

def start_pad(n):

    return ['~'] * n

Pair = Tuple[str, str]
Ngrams = List[Pair]
def ngrams(n, text:str) -> Ngrams:
    text=text.strip().split()


    pad=start_pad(n) + text
    s=[((' '.join(tuple(pad[i:i + n])), text[i])) for i in range(len(text))]
    #for x in range(len(text)):
    return s

    #pass


def create_ngram_model(model_class, path, n=2, k=0):

    model = model_class(n, k)
    with open(path, encoding='utf-8') as f:
        model.update(f.read())
    return model

################################################################################
# Part 1: Basic N-Gram Model
################################################################################
from collections import Counter
import collections

class NgramModel(object):


    def __init__(self, n, k):
        self.n = n
        self.k = k
        self.vocab = set()
        self.count = collections.defaultdict(int)
        self.ngram = collections.defaultdict(int)
        # self.occurances=Counter()
        # self.contextoccurance=Counter()
        # #pass
        # #self.count = collections.defaultdict(int)
        # #self.ngram = collections.defaultdict(int)
    def get_vocab(self):

        return self.vocab

    def update(self, text: str):


        # new_set_words=ngrams(self.n, text)
        # new_word_list = []
        # new_cont_list=[]
        # for x in new_set_words:
        #     new_cont_list.append(x)
        #     new_word_list.append(x[0])
        # #
        # #
        # # self.occurances =Counter(self.text_info)
        # # self.contextoccurance = Counter(new_word_list)
        #
        # self.occurances.update(new_cont_list)
        # self.contextoccurance.update(new_word_list)

        for words in ngrams(self.n,text):
            self.ngram[words] +=1
        for c,_ in ngrams(self.n,text):
            self.count[c] += 1


        text  = text.strip().split()
        for word in text:
            self.vocab.add(word)


    def prob(self, context: str, word: str):

        if context not in self.count and self.k == 0:
            return 1.0/len(self.get_vocab())

        if context not in self.count:
            count1 = 0.0
        else:
            count1 = self.count[context]

        if (context,word) not in self.ngram:
            count2 = 0.0
        else:
            count2 = self.ngram[(context,word)]

        return (count2 + self.k) / (count1 + len(self.get_vocab())*self.k)
    def random_word(self, context):

        #         random.seed(1)
        rand = random.random()
        #sort  vocab
        vocab = sorted(self.get_vocab())
        prob = 0


        if rand < self.prob(context, vocab[0]):
            return vocab[0]
        #for i in range(1,len(vocab)):
        for i in range(1,len(vocab)):
            prob =prob+ self.prob(context, vocab[i ])
            prob_curr_char = prob + self.prob(context, vocab[i])
            if prob <= rand < prob_curr_char:
                return vocab[i]
            else:
                continue

        return ''

    def random_text(self, length):

        createText = ""
        startword = " ".join(['~'] * self.n)

        cur_context = startword

        for x in range(1,length):
            ranch = self.random_word(startword)
            #print(ranch)
            createText = createText + " " + ranch

            cur_context += " " + ranch
            #print(cur_context)
            nlis = cur_context

            temp = nlis.split(" ")

            startword = temp[x :x  + self.n]
            #print(startword)
            if '' in startword:
                startword = "".join(startword)
            else:
                startword = " ".join(startword)

        final=createText[1:]
        #print(final)

        return final

    def perplexity(self, text):


        ngr = ngrams(self.n, text)

        text = text.strip().split()

        setvalu = 0
        for c, x in ngr:

            prba = self.prob(c, x)
            if prba == 0.0:
                result = float('inf')
                return result
            prob = self.prob(c, x)
            setvalu += math.log(prob)

        ress=-setvalu / len(text)
        #print(ress)
        #result = math.exp(ress)

        return math.exp(ress)




# m = NgramModel(1, 0)
# m.update('I love natural language processing')
# m.update('You love machine learning')
# print(m.perplexity('I love machine learning'))
#
# print(m.perplexity('I love python'))
# #
# m = NgramModel(1, 1)
# m.update('I love natural language processing')
# m.update('You love machine learning')
# print(m.perplexity('I love machine learning'))

#
# m = NgramModel(1, 0)
# m.update('You are welcome')
# m.update('We are friends')
# random.seed(1)
# print(m.random_text(25))

################################################################################
# Part 2: N-Gram Model with Interpolation
################################################################################

class NgramModelWithInterpolation(NgramModel):


    def __init__(self, n, k):
        pass

    def get_vocab(self):
        pass

    def update(self, text:str):
        pass

    def prob(self, context:str, word:str):
        pass

################################################################################
# Part 3: Your N-Gram Model Experimentation
################################################################################

if __name__ == '__main__':
    pass