import numpy as np
# You need to build your own model here instead of using well-built python packages such as sklearn

# from sklearn.naive_bayes import MultinomialNB
# from sklearn.linear_model import LogisticRegression
# from sklearn.linear_model import Perceptron
# You can use the models form sklearn packages to check the performance of your own models

class HateSpeechClassifier(object):
    """Base class for classifiers.
    """
    def __init__(self):
        pass
    def fit(self, X, Y):
        """Train your model based on training set
        
        Arguments:
            X {array} -- array of features, such as an N*D shape array, where N is the number of sentences, D is the size of feature dimensions
            Y {type} -- array of actual labels, such as an N shape array, where N is the nu,ber of sentences
        """
        pass
    def predict(self, X):
        """Predict labels based on your trained model
        
        Arguments:
            X {array} -- array of features, such as an N*D shape array, where N is the number of sentences, D is the size of feature dimensions
        
        Returns:
            array -- predict labels, such as an N shape array, where N is the nu,ber of sentences
        """
        pass


class AlwaysPreditZero(HateSpeechClassifier):
    """Always predict the 0
    """
    def predict(self, X):
        return [0]*len(X)

# TODO: Implement this
class NaiveBayesClassifier(HateSpeechClassifier):
    """Naive Bayes Classifier
    """
    def __init__(self):
        self.count={}
        self.cond_prob=None
        self.prior=None
        self.condition2=None
        #pass
        # Add your code here!
        #raise Exception("Must be implemented")
        

    def fit(self, X, Y):
        ## smoothing
        new_X=X+1

        ## p(y=1)
        self.prior =np.sum(Y)/len(Y)
        #p_y_0=1-p_y_1
        reshape_Y=np.reshape(np.asarray(Y),(len(Y),1))
        concXandY=np.hstack((new_X,reshape_Y))
        #conc[conc[-1] != 0].sum()
        sumColHate=concXandY[concXandY[:, -1] != 0].sum(axis=0)[:-1]
        sumHateWords=sum(sumColHate)
        sumColnotHate=concXandY[concXandY[:, -1] != 1].sum(axis=0)[:-1]
        sumloveWords=sum(sumColnotHate)
        self.cond_prob=sumColHate / sumHateWords
        self.condition2=sumColnotHate/sumloveWords




    
    def predict(self, X):

        X=X+1

        s=np.log(self.prior)+(X*np.log(self.cond_prob)).sum(axis=1)
        s1=np.log(1-self.prior)+(X*np.log(self.condition2)).sum(axis=1)
        maxs=np.max((s, s1), axis=0)
        list=[]
        for x,y in zip(s,s1):
            if x>=y:
                list.append(1)
            else:
                list.append(0)


        return list

        # Add your code here!
        #raise Exception("Must be implemented")

# TODO: Implement this
class LogisticRegressionClassifier(HateSpeechClassifier):
    """Logistic Regression Classifier
    """
    def __init__(self):
        self.weights=None
        # Add your code here!
        #raise Exception("Must be implemented")

    def crossEntropyLoss(self,y,yhat):
        ## yhat is our estimate
        loss=-y*np.log(yhat)+(1-y)*np.log(1-yhat)
        return loss
    def squishfunction(self,z):
        return 1/(1+np.e**(-z))

    def fit(self, X, Y):
        s = np.asarray([1] * X.shape[0])
        s=s.reshape((X.shape[0],1))
        X=np.hstack((X,s))
        ## splitting data into train/test 80 / 20 split
        xX=int(np.round(X.shape[0]*0.8))
        xY=1913-int(np.round(X.shape[0]*0.8))
        Xtest=X[xX:]
        Ytest=Y[xX:]
        X=X[:xX]
        Y=Y[:xX]



        # Add your code here!

        learning_rate=0.0001
        self.weights = np.asarray([0] * X.shape[1])

        ##sample from data
        #weightsbefore = self.weights
        counter=0
        while counter<100:
            counter+1
            weightsbefore = self.weights
            sample=np.random.choice(X.shape[0], 64)
            five_samples=np.asarray([X[s] for s in sample])
            sampleY=np.asarray([Y[s] for s in sample])

            s=np.asarray([((self.squishfunction(x.dot(self.weights.T)) - y) * x) for x,y in zip(five_samples,sampleY)])
            # for x,y in zip(five_samples,sampleY):
            #     learnTimesGradient=learnTimesGradient+((self.squishfunction(x.dot(self.weights.T)) - y) * x)
            #learnTimesGradient=0
            self.weights = self.weights - learning_rate*s.sum(axis=0)
            self.weights=self.weights-2*self.weights.sum()*.0001
            #print(np.sum(np.round(self.squishfunction(Xtest.dot(self.weights.T))) == Ytest) / Ytest.size)
            if np.sum(np.round(self.squishfunction(Xtest.dot(self.weights.T))) == Ytest) / Ytest.size>0.69:break



        #print(np.sum(np.round(self.squishfunction(Xtest.dot(self.weights.T))) == Ytest)/Ytest.size)





    
    def predict(self, X):
        s = np.asarray([1] * X.shape[0])
        s=s.reshape((X.shape[0],1))
        X=np.hstack((X,s))
        return np.round(self.squishfunction(X.dot(self.weights.T)))


        # Add your code here!



class PerceptronClassifier(HateSpeechClassifier):
    """Logistic Regression Classifier
    """

    def __init__(self):
        # Add your code here!
        raise Exception("Must be implemented")

    def fit(self, X, Y):
        # Add your code here!
        raise Exception("Must be implemented")

    def predict(self, X):
        # Add your code here!
        raise Exception("Must be implemented")

# you can change the following line to whichever classifier you want to use for bonus
# i.e to choose NaiveBayes classifier, you can write
# class BonusClassifier(NaiveBayes):
class BonusClassifier(PerceptronClassifier):
    def __init__(self):
        super().__init__()
